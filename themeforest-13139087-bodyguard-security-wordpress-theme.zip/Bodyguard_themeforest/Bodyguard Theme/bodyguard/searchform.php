<?php
/**
 * The template for displaying search forms in Metroblocks
 *
 */
?>

<form action="<?php echo esc_url(home_url('/')) ?>" class="searchform" id="searchform" method="get">
				<div>
					
					<input type="text" id="s" name="s" value="">
					<input type="submit" value="Search" id="searchsubmit">
				</div>
</form>


